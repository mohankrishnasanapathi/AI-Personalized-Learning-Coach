"""
Dashboard Visualizations and Analytics Engine for AI Personalized Learning Coach.
Generates interactive Plotly charts and metric summaries from SQLite database.
"""

import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from typing import Dict, Any, List
import database
from config import THEME_COLORS, THRESHOLDS

def create_completion_donut_chart(completed: int, pending: int) -> go.Figure:
    """
    Creates a donut chart comparing completed topics vs pending topics.
    """
    if completed == 0 and pending == 0:
        # Empty state placeholder
        labels = ["No Topics"]
        values = [1]
        colors = ["#E2E8F0"]
    else:
        labels = ["Completed Topics", "Pending Topics"]
        values = [completed, pending]
        colors = [THEME_COLORS["primary"], THEME_COLORS["primary_light"]]

    fig = go.Figure(data=[
        go.Pie(
            labels=labels,
            values=values,
            hole=0.68,
            marker=dict(colors=colors, line=dict(color="#FFFFFF", width=2)),
            textinfo="percent+label",
            textposition="outside",
            hoverinfo="label+value",
            showlegend=False
        )
    ])

    fig.update_layout(
        margin=dict(t=20, b=20, l=20, r=20),
        height=260,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Plus Jakarta Sans, sans-serif", color=THEME_COLORS["text_dark"]),
        annotations=[
            dict(
                text=f"<b>{completed}</b><br><span style='font-size:12px;color:#64748B;'>Done</span>",
                x=0.5, y=0.5,
                font_size=20,
                showarrow=False
            )
        ]
    )
    return fig

def create_quiz_score_history_chart(learner_id: int) -> go.Figure:
    """
    Creates an interactive line chart tracking quiz scores over time with a 70% benchmark line.
    """
    attempts = database.get_quiz_attempts_for_learner(learner_id)

    if not attempts:
        # Empty state chart
        fig = go.Figure()
        fig.add_annotation(
            text="No quizzes attempted yet.<br>Take a quiz in <b>Practice Quiz</b> to see your trend!",
            showarrow=False,
            font=dict(size=14, color=THEME_COLORS["text_muted"])
        )
        fig.update_layout(
            height=300,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            margin=dict(t=30, b=30, l=30, r=30)
        )
        return fig

    # Attempts are sorted DESC in database, so reverse for chronological chart
    chronological = list(reversed(attempts))
    df = pd.DataFrame(chronological)
    df["attempt_num"] = [f"Quiz #{i+1}" for i in range(len(df))]

    fig = go.Figure()

    # Benchmark threshold line (70%)
    fig.add_hline(
        y=THRESHOLDS["practice_needed"],
        line_dash="dot",
        line_color=THEME_COLORS["warning"],
        annotation_text="Target Benchmark (70%)",
        annotation_position="top left",
        annotation_font=dict(size=11, color=THEME_COLORS["warning"])
    )

    # Score line & markers
    fig.add_trace(go.Scatter(
        x=df["attempt_num"],
        y=df["score_percentage"],
        mode="lines+markers",
        name="Quiz Score %",
        line=dict(color=THEME_COLORS["primary"], width=3, shape="spline"),
        marker=dict(
            size=9,
            color=THEME_COLORS["primary_dark"],
            line=dict(color="#FFFFFF", width=2)
        ),
        hovertemplate="<b>%{x}</b><br>Topic: " + df["topic_name"] + "<br>Score: <b>%{y}%</b><extra></extra>"
    ))

    fig.update_layout(
        title=dict(
            text="<b>Quiz Performance Progression</b>",
            font=dict(size=16, color=THEME_COLORS["text_dark"])
        ),
        yaxis=dict(
            title="Score (%)",
            range=[0, 105],
            gridcolor="#EDE9FE",
            zeroline=False
        ),
        xaxis=dict(
            title="",
            gridcolor="#EDE9FE"
        ),
        height=320,
        margin=dict(t=50, b=30, l=40, r=30),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Plus Jakarta Sans, sans-serif")
    )
    return fig

def create_topic_performance_bar_chart(learner_id: int) -> go.Figure:
    """
    Creates a horizontal bar chart of average scores across topics,
    color-coded to highlight weak areas in amber/red and strong in purple/green.
    """
    attempts = database.get_quiz_attempts_for_learner(learner_id)

    if not attempts:
        fig = go.Figure()
        fig.add_annotation(
            text="No topic performance data available yet.",
            showarrow=False,
            font=dict(size=14, color=THEME_COLORS["text_muted"])
        )
        fig.update_layout(
            height=280,
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            margin=dict(t=20, b=20, l=20, r=20)
        )
        return fig

    df = pd.DataFrame(attempts)
    topic_summary = df.groupby("topic_name")["score_percentage"].mean().reset_index()
    topic_summary.columns = ["Topic", "Average Score"]
    topic_summary = topic_summary.sort_values(by="Average Score", ascending=True)

    # Truncate topic names for clean display
    topic_summary["Display_Topic"] = topic_summary["Topic"].apply(
        lambda x: x[:30] + "..." if len(x) > 30 else x
    )

    # Color mapping based on score
    colors = []
    for score in topic_summary["Average Score"]:
        if score < THRESHOLDS["fundamental_revision"]:
            colors.append("#EF4444")  # Red
        elif score < THRESHOLDS["practice_needed"]:
            colors.append("#F59E0B")  # Amber
        elif score < THRESHOLDS["good_progress"]:
            colors.append("#7C3AED")  # Purple
        else:
            colors.append("#10B981")  # Green

    fig = go.Figure(go.Bar(
        x=topic_summary["Average Score"],
        y=topic_summary["Display_Topic"],
        orientation="h",
        marker=dict(color=colors, line=dict(color="#FFFFFF", width=1.5)),
        text=topic_summary["Average Score"].apply(lambda v: f"{v:.1f}%"),
        textposition="outside",
        hovertemplate="<b>%{y}</b><br>Average Score: %{x:.1f}%<extra></extra>"
    ))

    fig.update_layout(
        title=dict(
            text="<b>Topic-Wise Performance Breakdown</b>",
            font=dict(size=16, color=THEME_COLORS["text_dark"])
        ),
        xaxis=dict(
            title="Average Score (%)",
            range=[0, 115],
            gridcolor="#EDE9FE",
            zeroline=False
        ),
        yaxis=dict(
            title="",
            autorange="reversed"
        ),
        height=max(280, len(topic_summary) * 45),
        margin=dict(t=50, b=30, l=120, r=40),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Plus Jakarta Sans, sans-serif")
    )
    return fig

def create_overall_progress_gauge(percentage: float) -> go.Figure:
    """
    Creates an elegant semi-circular gauge chart representing total plan completion.
    """
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=percentage,
        number=dict(suffix="%", font=dict(size=28, color=THEME_COLORS["primary_dark"])),
        gauge=dict(
            axis=dict(range=[0, 100], tickwidth=1, tickcolor="#CBD5E1"),
            bar=dict(color=THEME_COLORS["primary"], thickness=0.3),
            bgcolor="#F5F3FF",
            borderwidth=1,
            bordercolor="#DDD6FE",
            steps=[
                {"range": [0, 40], "color": "#EDE9FE"},
                {"range": [40, 70], "color": "#DDD6FE"},
                {"range": [70, 100], "color": "#C4B5FD"}
            ]
        )
    ))

    fig.update_layout(
        height=220,
        margin=dict(t=20, b=20, l=30, r=30),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Plus Jakarta Sans, sans-serif")
    )
    return fig


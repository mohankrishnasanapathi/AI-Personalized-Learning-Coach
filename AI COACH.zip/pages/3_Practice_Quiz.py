"""
AI Practice Quiz & Performance Analysis (Modules 4 & 5).
Generates 5 targeted multiple choice questions via Gemini, calculates scores in Python,
provides detailed explanations, identifies weak areas, and stores attempts in SQLite.
"""

import streamlit as st
from config import APP_NAME, APP_ICON, apply_custom_theme, render_sidebar_status, THEME_COLORS, THRESHOLDS
import database
import quiz_manager
import performance_analyzer

st.set_page_config(
    page_title=f"{APP_NAME} - Practice Quiz",
    page_icon=APP_ICON,
    layout="wide"
)

apply_custom_theme()
render_sidebar_status()

active_learner = database.get_active_learner()

if not active_learner:
    st.warning("⚠️ No active learner profile found. Please set up your profile first.")
    if st.button("👉 Set Up Learner Profile", type="primary"):
        st.switch_page("pages/1_Learning_Profile.py")
    st.stop()

active_plan = database.get_active_study_plan(active_learner["id"])
if not active_plan:
    st.warning("⚠️ Please generate a study plan first before taking practice quizzes.")
    if st.button("👉 Go to Study Plan", type="primary"):
        st.switch_page("pages/2_Study_Plan.py")
    st.stop()

topics = database.get_plan_topics(active_plan["id"])
if not topics:
    st.error("No topics found in active plan.")
    st.stop()

# Header
st.markdown(
    f"""
    <div style="margin-bottom: 20px;">
        <span class="badge badge-purple">Modules 4 & 5</span>
        <h1 style="color: #1E1B4B; margin: 6px 0 6px 0;">AI Practice Quiz & Performance Analysis</h1>
        <p style="color: #64748B; font-size: 1rem; margin: 0;">
            Select a topic from your study plan, answer 5 diagnostic questions, and receive instant Python-evaluated feedback.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Topic Selector
topic_options = {t["id"]: f"Day {t['day_number']}: {t['topic_name']}" for t in topics}

# Check if a topic was pre-selected from Study Plan page
default_topic_id = st.session_state.get("selected_quiz_topic_id", topics[0]["id"])
if default_topic_id not in topic_options:
    default_topic_id = topics[0]["id"]

col_sel1, col_sel2 = st.columns([3, 1])
with col_sel1:
    selected_topic_id = st.selectbox(
        "Select Topic to Practice:",
        options=list(topic_options.keys()),
        format_func=lambda x: topic_options[x],
        index=list(topic_options.keys()).index(default_topic_id)
    )
    # Update session state
    st.session_state["selected_quiz_topic_id"] = selected_topic_id

selected_topic = next((t for t in topics if t["id"] == selected_topic_id), topics[0])

# State key for active quiz
quiz_state_key = f"quiz_data_{selected_topic['id']}"
quiz_submitted_key = f"quiz_submitted_{selected_topic['id']}"
quiz_result_key = f"quiz_result_{selected_topic['id']}"

with col_sel2:
    st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
    if st.button("🔄 Generate New Questions", use_container_width=True, help="Fetch fresh questions for this topic"):
        st.session_state.pop(quiz_state_key, None)
        st.session_state.pop(quiz_submitted_key, None)
        st.session_state.pop(quiz_result_key, None)
        st.rerun()

# Topic Context Banner
st.markdown(
    f"""
    <div class="coach-card" style="padding: 16px 20px; background: #FAF5FF; border-left: 5px solid {THEME_COLORS['primary']}; margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
            <div>
                <strong style="color: #1E1B4B; font-size: 1.1rem;">Active Quiz: {selected_topic['topic_name']}</strong>
                <div style="color: #64748B; font-size: 0.86rem; margin-top: 4px;">
                    Subject: <strong>{active_learner['subject']}</strong> &bull; Level: <strong>{active_learner['knowledge_level']}</strong> &bull; 
                    Format: <strong>5 Multiple Choice Questions</strong> &bull; Evaluator: <strong>Python Scoring Engine</strong>
                </div>
            </div>
            <div>
                <span class="badge badge-purple">5 Questions</span>
            </div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Fetch or Generate Quiz Questions
if quiz_state_key not in st.session_state:
    with st.spinner(f"🧠 Generating 5 diagnostic questions for '{selected_topic['topic_name']}' with Gemini..."):
        questions = quiz_manager.fetch_or_generate_quiz(selected_topic, active_learner)
        st.session_state[quiz_state_key] = questions
        st.session_state[quiz_submitted_key] = False

questions = st.session_state[quiz_state_key]
is_submitted = st.session_state.get(quiz_submitted_key, False)

# ========================================================================= #
# QUIZ TAKING FORM (When not submitted)
# ========================================================================= #
if not is_submitted:
    st.markdown("### 📋 Answer the Questions Below")
    st.caption("Select the best answer for each question, then click 'Submit Quiz for Evaluation' at the bottom.")

    with st.form("quiz_submission_form"):
        user_selections = {}

        for idx, q in enumerate(questions):
            st.markdown(
                f"""
                <div style="background: #FFFFFF; border: 1px solid #EDE9FE; border-radius: 12px; padding: 18px; margin-bottom: 16px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                        <span style="font-weight: 700; color: #7C3AED; font-size: 0.85rem;">QUESTION {idx + 1} OF 5</span>
                        <span class="badge" style="background: #F1F5F9; color: #475569;">{q.get('difficulty', 'Medium')}</span>
                    </div>
                    <div style="font-size: 1.05rem; font-weight: 600; color: #1E1B4B; margin-bottom: 12px;">
                        {q['question']}
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )

            # Options
            opts = q.get("options", {})
            opt_labels = [f"{k}: {opts.get(k, '')}" for k in ["A", "B", "C", "D"] if k in opts]

            selected_str = st.radio(
                f"Choose your answer for Question {idx + 1}:",
                options=opt_labels,
                index=None,
                key=f"q_choice_{selected_topic['id']}_{idx}",
                label_visibility="collapsed"
            )

            if selected_str:
                chosen_opt_letter = selected_str.split(":")[0].strip().upper()
                user_selections[idx] = chosen_opt_letter
            else:
                user_selections[idx] = ""

            st.markdown("<div style='margin-bottom: 14px;'></div>", unsafe_allow_html=True)

        st.markdown("---")
        submit_btn = st.form_submit_button("🚀 Submit Quiz for Python Evaluation", type="primary", use_container_width=True)

    if submit_btn:
        # Check if all answered
        unanswered = [i + 1 for i, v in user_selections.items() if not v]
        if unanswered:
            st.warning(f"⚠️ Please answer all questions before submitting. Unanswered: Question {', '.join(map(str, unanswered))}")
        else:
            with st.spinner("Python evaluating answer key and updating SQLite progress..."):
                # Strict requirement: Python calculates quiz scores using answer key. Never ask Gemini to calculate the score.
                evaluation = quiz_manager.evaluate_quiz_answers(questions, user_selections)
                
                # Record to SQLite database and compute adaptive recommendations
                attempt_id, recommendation = quiz_manager.record_quiz_submission(
                    learner=active_learner,
                    topic=selected_topic,
                    plan_id=active_plan["id"],
                    evaluation_result=evaluation
                )

                st.session_state[quiz_submitted_key] = True
                st.session_state[quiz_result_key] = {
                    "attempt_id": attempt_id,
                    "evaluation": evaluation,
                    "recommendation": recommendation
                }
                st.rerun()

# ========================================================================= #
# QUIZ RESULTS & MODULE 5 PERFORMANCE ANALYSIS (When submitted)
# ========================================================================= #
else:
    result_data = st.session_state.get(quiz_result_key, {})
    evaluation = result_data.get("evaluation", {})
    rec = result_data.get("recommendation", {})
    attempt_id = result_data.get("attempt_id")

    score_pct = evaluation.get("score_percentage", 0.0)
    correct_count = evaluation.get("correct_answers", 0)
    total_count = evaluation.get("total_questions", 5)
    incorrect_count = evaluation.get("incorrect_answers", 0)

    # Performance tier mapping
    tier_info = performance_analyzer.get_performance_tier(score_pct)

    # Results Header Card
    st.markdown(
        f"""
        <div class="coach-card" style="border-left: 8px solid {tier_info['color_hex']}; padding: 24px; margin-bottom: 24px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div>
                    <span class="badge badge-{tier_info['badge_color']}">{tier_info['tier']}</span>
                    <h2 style="margin: 8px 0 4px 0; color: #1E1B4B;">Quiz Evaluation: {score_pct:.0f}%</h2>
                    <p style="color: #64748B; font-size: 0.95rem; margin: 0;">
                        Topic: <strong>{selected_topic['topic_name']}</strong> &bull; Attempt #{attempt_id} saved to SQLite
                    </p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 2.4rem; font-weight: 800; color: {tier_info['color_hex']};">
                        {correct_count} / {total_count}
                    </div>
                    <div style="font-size: 0.8rem; color: #64748B; text-transform: uppercase; font-weight: 600;">Correct Answers</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # 4 Quick Metric Cards
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(
            f"""
            <div class="stat-card">
                <div class="stat-value" style="color: #6D28D9;">{total_count}</div>
                <div class="stat-label">Total Questions</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with m2:
        st.markdown(
            f"""
            <div class="stat-card">
                <div class="stat-value" style="color: #10B981;">{correct_count}</div>
                <div class="stat-label">Correct Answers</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with m3:
        st.markdown(
            f"""
            <div class="stat-card">
                <div class="stat-value" style="color: #EF4444;">{incorrect_count}</div>
                <div class="stat-label">Incorrect Answers</div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with m4:
        st.markdown(
            f"""
            <div class="stat-card">
                <div class="stat-value" style="color: {tier_info['color_hex']};">{score_pct:.0f}%</div>
                <div class="stat-label">Score Percentage</div>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("<div style='margin-bottom: 24px;'></div>", unsafe_allow_html=True)

    # --- ADAPTIVE COACH RECOMMENDATION SECTION ---
    st.markdown("### 🧭 AI Performance Analysis & Recommendations")
    
    rec_c1, rec_c2 = st.columns([2, 1])
    with rec_c1:
        st.markdown(
            f"""
            <div class="coach-card" style="background: #FFFFFF;">
                <h4 style="color: #6D28D9; margin-top: 0;">💡 Diagnostic Assessment</h4>
                <p style="font-size: 0.98rem; color: #1E1B4B; line-height: 1.6;">
                    {tier_info['message']}
                </p>
                <div style="background: #F9F8FF; border: 1px solid #EDE9FE; border-radius: 8px; padding: 12px; margin-top: 10px;">
                    <strong style="color: #4C1D95;">Coach Guidance:</strong>
                    <div style="color: #475569; font-size: 0.9rem; margin-top: 4px;">{tier_info['guidance']}</div>
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )
    with rec_c2:
        st.markdown(
            f"""
            <div class="coach-card" style="background: #FAF5FF; height: 100%;">
                <h4 style="color: #1E1B4B; margin-top: 0;">🎯 Recommended Actions</h4>
                <ul style="font-size: 0.88rem; color: #475569; line-height: 1.6; margin: 0; padding-left: 18px;">
            """ +
            "".join([f"<li>{action}</li>" for action in rec.get("actions", [])]) +
            """
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

    # Action Buttons: Retry Quiz, Ask AI Assistant, Next Topic, or Dashboard
    st.markdown("<div style='margin-top: 14px;'></div>", unsafe_allow_html=True)
    b_col1, b_col2, b_col3, b_col4 = st.columns(4)

    with b_col1:
        if st.button("🔄 Retake Quiz", use_container_width=True):
            st.session_state[quiz_submitted_key] = False
            st.session_state.pop(quiz_result_key, None)
            st.rerun()

    with b_col2:
        if st.button("🎲 Fresh Question Set", use_container_width=True):
            st.session_state.pop(quiz_state_key, None)
            st.session_state.pop(quiz_submitted_key, None)
            st.session_state.pop(quiz_result_key, None)
            st.rerun()

    with b_col3:
        if st.button("💬 Discuss with AI Tutor", use_container_width=True, type="primary"):
            st.session_state["prefill_chat_topic"] = f"{selected_topic['topic_name']} (scored {score_pct:.0f}%)"
            st.switch_page("pages/4_AI_Assistant.py")

    with b_col4:
        if st.button("📊 View Progress Dashboard", use_container_width=True):
            st.switch_page("pages/5_Progress_Dashboard.py")

    # --- DETAILED QUESTION-BY-QUESTION REVIEW ---
    st.markdown("---")
    st.markdown("### 🔍 Question-By-Question Detailed Review")
    st.caption("Review explanations for correct and incorrect answers to cement understanding.")

    eval_qs = evaluation.get("evaluated_questions", [])
    for idx, eq in enumerate(eval_qs):
        is_correct = bool(eq.get("is_correct"))
        user_opt = eq.get("user_selected_option", "")
        correct_opt = eq.get("correct_option", "")
        opts = eq.get("options", {})

        border_color = "#10B981" if is_correct else "#EF4444"
        icon = "✅" if is_correct else "❌"
        verdict = "Correct!" if is_correct else "Incorrect"

        st.markdown(
            f"""
            <div class="coach-card" style="border-left: 6px solid {border_color}; margin-bottom: 16px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="font-weight: 700; color: #1E1B4B;">Question {idx + 1} &bull; {verdict} {icon}</span>
                    <span class="badge" style="background: {'#D1FAE5' if is_correct else '#FEE2E2'}; color: {'#065F46' if is_correct else '#991B1B'};">
                        Your Choice: Option {user_opt} | Correct: Option {correct_opt}
                    </span>
                </div>
                <div style="font-size: 1.05rem; font-weight: 600; color: #1E1B4B; margin-bottom: 12px;">
                    {eq['question']}
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        # Show options with color coding
        for opt_key in ["A", "B", "C", "D"]:
            if opt_key in opts:
                is_this_correct = (opt_key == correct_opt)
                is_this_user = (opt_key == user_opt)

                if is_this_correct:
                    bg = "#ECFDF5"
                    border = "1px solid #10B981"
                    badge_str = " <span style='color: #065F46; font-weight: bold;'>✓ Correct Answer</span>"
                elif is_this_user and not is_correct:
                    bg = "#FEF2F2"
                    border = "1px solid #EF4444"
                    badge_str = " <span style='color: #991B1B; font-weight: bold;'>✗ Your Choice</span>"
                else:
                    bg = "#FFFFFF"
                    border = "1px solid #E2E8F0"
                    badge_str = ""

                st.markdown(
                    f"""
                    <div style="background: {bg}; border: {border}; border-radius: 8px; padding: 10px 14px; margin-bottom: 6px; font-size: 0.92rem;">
                        <strong>{opt_key}:</strong> {opts[opt_key]} {badge_str}
                    </div>
                    """,
                    unsafe_allow_html=True
                )

        # Explanation block
        st.markdown(
            f"""
            <div style="background: #F5F3FF; border-radius: 8px; padding: 12px 14px; margin-top: 10px; font-size: 0.9rem; color: #4C1D95;">
                <strong>💡 Pedagogical Explanation:</strong> {eq.get('explanation', '')}
            </div>
            <div style="margin-bottom: 16px;"></div>
            """,
            unsafe_allow_html=True
        )


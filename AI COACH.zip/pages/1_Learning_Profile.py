"""
Learner Profile and Setup (Module 2).
Collects student profile, subject, goals, schedule, and learning style,
validates inputs, and persists to SQLite.
"""

import streamlit as st
from config import APP_NAME, APP_ICON, apply_custom_theme, render_sidebar_status, THEME_COLORS
import database
import learning_plan

st.set_page_config(
    page_title=f"{APP_NAME} - Learner Profile",
    page_icon=APP_ICON,
    layout="wide"
)

apply_custom_theme()
render_sidebar_status()

st.markdown(
    """
    <div style="margin-bottom: 20px;">
        <span class="badge badge-purple">Module 2</span>
        <h1 style="color: #1E1B4B; margin: 6px 0 6px 0;">Learner Profile & Setup</h1>
        <p style="color: #64748B; font-size: 1rem; margin: 0;">
            Define your learning goals, current background, and time commitment to generate a tailored curriculum.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Active learner check
active_learner = database.get_active_learner()
all_learners = database.get_all_learners()

# Preset Quick-Fill Templates for easy evaluator testing
st.markdown("##### ⚡ Quick-Fill Templates (Click to auto-populate form)")
pcol1, pcol2, pcol3 = st.columns(3)

preset_selected = None
with pcol1:
    if st.button("🐍 Python Fundamentals (7 Days, 45m)", use_container_width=True):
        st.session_state["form_name"] = "Alex Johnson"
        st.session_state["form_subject"] = "Python"
        st.session_state["form_goal"] = "Learn Python fundamentals and core data structures for scripting"
        st.session_state["form_level"] = "Beginner"
        st.session_state["form_days"] = 7
        st.session_state["form_minutes"] = 45
        st.session_state["form_style"] = "Mixed"
        st.rerun()

with pcol2:
    if st.button("📊 SQL for Data Analysis (10 Days, 30m)", use_container_width=True):
        st.session_state["form_name"] = "Sarah Chen"
        st.session_state["form_subject"] = "SQL & Relational Databases"
        st.session_state["form_goal"] = "Master SQL queries, joins, aggregations, and window functions for analytics"
        st.session_state["form_level"] = "Intermediate"
        st.session_state["form_days"] = 10
        st.session_state["form_minutes"] = 30
        st.session_state["form_style"] = "Practice"
        st.rerun()

with pcol3:
    if st.button("🌐 Web Development with React (14 Days, 60m)", use_container_width=True):
        st.session_state["form_name"] = "Devon Miller"
        st.session_state["form_subject"] = "React & Modern Web Development"
        st.session_state["form_goal"] = "Build modern interactive single page applications using React hooks and state"
        st.session_state["form_level"] = "Beginner"
        st.session_state["form_days"] = 14
        st.session_state["form_minutes"] = 60
        st.session_state["form_style"] = "Examples"
        st.rerun()

st.markdown("<div style='margin-bottom: 12px;'></div>", unsafe_allow_html=True)

# Form Container
with st.container():
    # If active learner exists, default to their values unless user clicked quick fill
    default_name = st.session_state.get("form_name", active_learner["name"] if active_learner else "")
    default_subject = st.session_state.get("form_subject", active_learner["subject"] if active_learner else "")
    default_goal = st.session_state.get("form_goal", active_learner["goal"] if active_learner else "")
    default_level = st.session_state.get("form_level", active_learner["knowledge_level"] if active_learner else "Beginner")
    default_days = st.session_state.get("form_days", active_learner["target_days"] if active_learner else 7)
    default_minutes = st.session_state.get("form_minutes", active_learner["daily_minutes"] if active_learner else 45)
    default_style = st.session_state.get("form_style", active_learner["learning_style"] if active_learner else "Mixed")

    levels = ["Beginner", "Intermediate", "Advanced"]
    styles = ["Reading", "Examples", "Practice", "Mixed"]

    with st.form("learner_setup_form", clear_on_submit=False):
        st.markdown("### 📝 Student Information")

        c1, c2 = st.columns([1, 1])
        with c1:
            name_input = st.text_input(
                "1. Student Full Name *",
                value=default_name,
                placeholder="e.g. Maya Patel",
                help="Your name or preferred nickname for personalized coaching feedback."
            )
        with c2:
            subject_input = st.text_input(
                "2. Subject / Technology to Learn *",
                value=default_subject,
                placeholder="e.g. Python, Machine Learning, JavaScript, Data Structures",
                help="The core language, framework, or concept you wish to study."
            )

        goal_input = st.text_area(
            "3. Specific Learning Goal *",
            value=default_goal,
            placeholder="e.g. Learn Python fundamentals from scratch to pass junior coding interviews and build mini-projects.",
            help="Detail what you wish to achieve. The AI curriculum adapts to this objective.",
            height=85
        )

        st.markdown("### ⚙️ Study Preferences & Commitment")
        col_pref1, col_pref2, col_pref3 = st.columns(3)

        with col_pref1:
            level_idx = levels.index(default_level) if default_level in levels else 0
            level_input = st.selectbox(
                "4. Current Knowledge Level *",
                options=levels,
                index=level_idx,
                help="Beginner: no prior experience; Intermediate: knows basics; Advanced: deep-dive & optimization."
            )

        with col_pref2:
            days_input = st.number_input(
                "5. Target Duration (Days) *",
                min_value=1,
                max_value=90,
                value=int(default_days),
                step=1,
                help="Number of days for your curriculum (e.g. 7, 14, 30 days)."
            )

        with col_pref3:
            minutes_input = st.number_input(
                "6. Available Daily Study Time (Minutes) *",
                min_value=15,
                max_value=240,
                value=int(default_minutes),
                step=5,
                help="Minutes per day dedicated to study (e.g. 30, 45, 60 minutes)."
            )

        style_idx = styles.index(default_style) if default_style in styles else 3
        style_input = st.radio(
            "7. Preferred Learning Style *",
            options=styles,
            index=style_idx,
            horizontal=True,
            help="Reading: conceptual texts; Examples: step-by-step code samples; Practice: hands-on exercises; Mixed: balanced approach."
        )

        st.markdown("<div style='margin-top: 14px;'></div>", unsafe_allow_html=True)
        col_btn1, col_btn2 = st.columns([1, 1])
        with col_btn1:
            save_btn = st.form_submit_button("💾 Save Profile & Generate Study Plan", type="primary", use_container_width=True)
        with col_btn2:
            update_only_btn = st.form_submit_button("📁 Save Profile Only", use_container_width=True)

    if save_btn or update_only_btn:
        # Validate inputs
        if not name_input or not name_input.strip():
            st.error("❌ Student Name is required.")
        else:
            is_valid, err_msg = learning_plan.validate_plan_inputs(
                subject=subject_input,
                goal=goal_input,
                knowledge_level=level_input,
                target_days=int(days_input),
                daily_minutes=int(minutes_input),
                learning_style=style_input
            )

            if not is_valid:
                st.error(f"❌ Validation Error: {err_msg}")
            else:
                # Save to database
                # If editing active learner, update, else create new
                existing_id = active_learner["id"] if active_learner and active_learner["name"].lower() == name_input.strip().lower() else None
                learner_id = database.save_learner(
                    name=name_input.strip(),
                    subject=subject_input.strip(),
                    goal=goal_input.strip(),
                    knowledge_level=level_input,
                    target_days=int(days_input),
                    daily_minutes=int(minutes_input),
                    learning_style=style_input,
                    learner_id=existing_id
                )

                database.set_active_learner_id(learner_id)
                st.success(f"✅ Profile for **{name_input.strip()}** successfully saved in SQLite!")

                if save_btn:
                    with st.spinner("🧠 Generating personalized study plan with Google Gemini..."):
                        success, result = learning_plan.create_and_save_study_plan(
                            learner_id=learner_id,
                            subject=subject_input.strip(),
                            goal=goal_input.strip(),
                            knowledge_level=level_input,
                            target_days=int(days_input),
                            daily_minutes=int(minutes_input),
                            learning_style=style_input
                        )
                        if success:
                            st.success(f"🎉 Generated {days_input}-day study plan! Redirecting...")
                            st.switch_page("pages/2_Study_Plan.py")
                        else:
                            st.error(f"⚠️ Plan generation error: {result}")
                else:
                    st.info("You can view or generate your study plan whenever you are ready in **2. Study Plan**.")
                    st.rerun()

# Existing learners manager
if len(all_learners) > 1:
    st.markdown("---")
    st.markdown("### 👥 Switch Between Saved Learner Profiles")
    for l in all_learners:
        is_active = (active_learner and active_learner["id"] == l["id"])
        c_p1, c_p2, c_p3 = st.columns([2, 1, 1])
        with c_p1:
            badge = " <span class='badge badge-success'>Active</span>" if is_active else ""
            st.markdown(f"**{l['name']}** — *{l['subject']}* ({l['knowledge_level']}){badge}", unsafe_allow_html=True)
            st.caption(f"Goal: {l['goal'][:60]}... | {l['target_days']} Days @ {l['daily_minutes']} min/day")
        with c_p2:
            if not is_active:
                if st.button("Select Profile", key=f"switch_learner_{l['id']}", use_container_width=True):
                    database.set_active_learner_id(l["id"])
                    st.rerun()
            else:
                st.write("Current profile")
        with c_p3:
            st.caption(f"Created: {l['created_at'][:10]}")


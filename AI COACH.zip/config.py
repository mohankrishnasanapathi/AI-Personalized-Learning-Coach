"""
Configuration settings, design system constants, and shared styling for
AI Personalized Learning Coach.
"""

import os
import streamlit as st
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# App Information
APP_NAME = "AI Personalized Learning Coach"
APP_TAGLINE = "Your Intelligent Adaptive Study Companion"
APP_ICON = "🎓"
VERSION = "1.0.0"

# Design Palette (Light Lavender, Soft Purple, Deep Violet, Clean White)
THEME_COLORS = {
    "primary": "#7C3AED",          # Vibrant Soft Purple
    "primary_dark": "#6D28D9",     # Deep Purple
    "primary_light": "#DDD6FE",    # Light Lavender Accent
    "secondary": "#A78BFA",        # Soft Violet
    "background": "#F5F3FF",       # Very Light Lavender
    "surface": "#FFFFFF",          # Pure White
    "surface_subtle": "#F9F8FF",   # Hint of purple/white
    "text_dark": "#1E1B4B",        # Midnight Indigo
    "text_muted": "#64748B",       # Slate Grey
    "border": "#E9D5FF",          # Border lavender
    "success": "#10B981",          # Emerald Green
    "warning": "#F59E0B",          # Amber
    "danger": "#EF4444",           # Rose Red
    "info": "#3B82F6",             # Sky Blue
}

# Adaptive Performance Thresholds (Configurable)
THRESHOLDS = {
    "fundamental_revision": 40.0,   # Below 40%
    "practice_needed": 70.0,        # 40% - 69%
    "good_progress": 90.0,          # 70% - 89%
    "advanced_ready": 100.0         # 90% - 100%
}

def get_gemini_api_key() -> str:
    """
    Retrieve Gemini API key with priority:
    1. Streamlit session_state (user entered in UI)
    2. Environment variable GEMINI_API_KEY
    3. Environment variable GOOGLE_API_KEY
    """
    if "user_api_key" in st.session_state and st.session_state["user_api_key"]:
        return st.session_state["user_api_key"].strip()
    
    key = os.environ.get("GEMINI_API_KEY", "") or os.environ.get("GOOGLE_API_KEY", "")
    return key.strip()

def apply_custom_theme():
    """
    Inject professional custom CSS for the light lavender & soft purple aesthetic.
    """
    custom_css = f"""
    <style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap');

    html, body, [class*="css"] {{
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
    }}

    /* Global App Container */
    .stApp {{
        background: linear-gradient(180deg, #F9F8FF 0%, #F5F3FF 100%);
        color: {THEME_COLORS["text_dark"]};
    }}

    /* Sidebar Styling */
    section[data-testid="stSidebar"] {{
        background: linear-gradient(180deg, #FFFFFF 0%, #F5F3FF 100%);
        border-right: 1px solid {THEME_COLORS["border"]};
    }}

    section[data-testid="stSidebar"] .stMarkdown {{
        color: {THEME_COLORS["text_dark"]};
    }}

    /* Modern Card Container */
    .coach-card {{
        background: {THEME_COLORS["surface"]};
        border-radius: 16px;
        padding: 24px;
        border: 1px solid {THEME_COLORS["border"]};
        box-shadow: 0 4px 20px -2px rgba(124, 58, 237, 0.06), 0 2px 6px -1px rgba(0, 0, 0, 0.03);
        margin-bottom: 20px;
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }}

    .coach-card:hover {{
        box-shadow: 0 8px 30px -4px rgba(124, 58, 237, 0.12);
    }}

    .coach-card-header {{
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 16px;
        border-bottom: 1px solid #F3E8FF;
        padding-bottom: 12px;
    }}

    /* Hero Banner */
    .hero-banner {{
        background: linear-gradient(135deg, #7C3AED 0%, #6D28D9 50%, #4C1D95 100%);
        border-radius: 20px;
        padding: 36px 32px;
        color: #FFFFFF;
        margin-bottom: 28px;
        box-shadow: 0 10px 25px -5px rgba(109, 40, 217, 0.35);
        position: relative;
        overflow: hidden;
    }}

    .hero-banner h1 {{
        color: #FFFFFF !important;
        font-weight: 800;
        margin-bottom: 8px;
    }}

    .hero-banner p {{
        color: #EDE9FE;
        font-size: 1.1rem;
        max-width: 680px;
    }}

    /* Pill Badges */
    .badge {{
        display: inline-block;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.025em;
        text-transform: uppercase;
    }}

    .badge-purple {{
        background: #EDE9FE;
        color: #6D28D9;
        border: 1px solid #DDD6FE;
    }}

    .badge-success {{
        background: #D1FAE5;
        color: #065F46;
        border: 1px solid #A7F3D0;
    }}

    .badge-warning {{
        background: #FEF3C7;
        color: #92400E;
        border: 1px solid #FDE68A;
    }}

    .badge-danger {{
        background: #FEE2E2;
        color: #991B1B;
        border: 1px solid #FECACA;
    }}

    /* Stat Cards */
    .stat-card {{
        background: #FFFFFF;
        border-radius: 14px;
        padding: 18px;
        border: 1px solid #E9D5FF;
        box-shadow: 0 2px 10px rgba(124, 58, 237, 0.05);
        text-align: center;
    }}

    .stat-value {{
        font-size: 1.8rem;
        font-weight: 700;
        color: #6D28D9;
        line-height: 1.2;
    }}

    .stat-label {{
        font-size: 0.82rem;
        color: #64748B;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: 4px;
        font-weight: 600;
    }}

    /* Buttons */
    .stButton>button {{
        border-radius: 10px;
        font-weight: 600;
        transition: all 0.2s ease-in-out;
        border: none;
    }}

    .stButton>button:hover {{
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(124, 58, 237, 0.2);
    }}

    /* Input styling */
    .stTextInput>div>div>input, .stSelectbox>div>div, .stNumberInput>div>div>input {{
        border-radius: 10px !important;
        border: 1px solid #DDD6FE !important;
    }}

    .stTextInput>div>div>input:focus, .stNumberInput>div>div>input:focus {{
        border-color: #7C3AED !important;
        box-shadow: 0 0 0 2px rgba(124, 58, 237, 0.2) !important;
    }}

    /* Custom Scrollbar */
    ::-webkit-scrollbar {{
        width: 8px;
        height: 8px;
    }}
    ::-webkit-scrollbar-track {{
        background: #F5F3FF;
    }}
    ::-webkit-scrollbar-thumb {{
        background: #DDD6FE;
        border-radius: 4px;
    }}
    ::-webkit-scrollbar-thumb:hover {{
        background: #C4B5FD;
    }}
    </style>
    """
    st.markdown(custom_css, unsafe_allow_html=True)

def render_sidebar_status():
    """
    Renders standardized sidebar navigation header, active learner status, and API key management.
    """
    from database import get_active_learner, get_all_learners, set_active_learner_id

    st.sidebar.markdown(
        f"""
        <div style="display: flex; align-items: center; gap: 10px; padding: 10px 0 16px 0; border-bottom: 1px solid #EDE9FE;">
            <div style="background: linear-gradient(135deg, #7C3AED, #6D28D9); width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 22px; color: white;">
                {APP_ICON}
            </div>
            <div>
                <div style="font-weight: 800; font-size: 1.05rem; color: #1E1B4B; line-height: 1.1;">AI Learning Coach</div>
                <div style="font-size: 0.75rem; color: #7C3AED; font-weight: 600;">Personalized Study Assistant</div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )

    # Active Learner selector/status
    all_learners = get_all_learners()
    active_learner = get_active_learner()

    if all_learners:
        st.sidebar.markdown("<div style='margin-top: 14px;'></div>", unsafe_allow_html=True)
        learner_options = {l["id"]: f"{l['name']} ({l['subject']})" for l in all_learners}
        
        current_id = active_learner["id"] if active_learner else all_learners[0]["id"]
        # Ensure current_id is in options
        if current_id not in learner_options:
            current_id = all_learners[0]["id"]

        selected_id = st.sidebar.selectbox(
            "👤 Active Learner",
            options=list(learner_options.keys()),
            format_func=lambda x: learner_options[x],
            index=list(learner_options.keys()).index(current_id),
            key="sidebar_active_learner_select"
        )
        if active_learner is None or selected_id != active_learner["id"]:
            set_active_learner_id(selected_id)
            st.rerun()

        if active_learner:
            st.sidebar.markdown(
                f"""
                <div style="background: #F5F3FF; border: 1px solid #DDD6FE; border-radius: 8px; padding: 8px 12px; margin-top: -6px; margin-bottom: 14px; font-size: 0.78rem;">
                    <div><strong>Level:</strong> {active_learner['knowledge_level']} | <strong>Daily:</strong> {active_learner['daily_minutes']}m</div>
                    <div><strong>Goal:</strong> {active_learner['goal'][:40]}{'...' if len(active_learner['goal']) > 40 else ''}</div>
                </div>
                """,
                unsafe_allow_html=True
            )
    else:
        st.sidebar.info("💡 No learner profile found. Create one in **Learner Profile**.")

    # API Key Configuration in Sidebar Expander
    api_key = get_gemini_api_key()
    with st.sidebar.expander("🔑 Gemini API Settings", expanded=not bool(api_key)):
        if api_key:
            masked = api_key[:4] + "..." + api_key[-4:] if len(api_key) > 8 else "***"
            st.markdown(f"Status: <span class='badge badge-success'>Connected</span>", unsafe_allow_html=True)
            st.caption(f"Active Key: `{masked}`")
        else:
            st.markdown(f"Status: <span class='badge badge-warning'>Fallback / Demo Mode</span>", unsafe_allow_html=True)
            st.caption("AI features will run with built-in intelligent sample plans and quizzes. Provide an API key for live Gemini 2.5 generations.")

        new_key = st.text_input(
            "Enter Gemini API Key",
            type="password",
            value=st.session_state.get("user_api_key", ""),
            placeholder="AIzaSy...",
            help="Free from Google AI Studio: https://aistudio.google.com/app/apikey"
        )
        if st.button("Save API Key", use_container_width=True):
            if new_key:
                st.session_state["user_api_key"] = new_key.strip()
                st.success("API Key updated for this session!")
                st.rerun()
            else:
                st.session_state.pop("user_api_key", None)
                st.rerun()

    # Footer
    st.sidebar.markdown("---")
    st.sidebar.caption("© 2026 AI Personalized Learning Coach • Built with Streamlit & Gemini")


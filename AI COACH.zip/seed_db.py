"""
Seed initial test data for demonstration and evaluation.
Populates an example Python learner, 7-day study plan, initial quiz attempts, and chat history.
"""

import database
import json
import os

def seed():
    print("Initializing database...")
    database.init_db()

    # Check if learner already exists
    existing = database.get_all_learners()
    if existing:
        print(f"Database already contains {len(existing)} learner(s).")
        return

    print("Seeding sample learner Alex Johnson...")
    learner_id = database.save_learner(
        name="Alex Johnson",
        subject="Python",
        goal="Master Python fundamentals, control flow, functions, and write practical scripts",
        knowledge_level="Beginner",
        target_days=7,
        daily_minutes=45,
        learning_style="Mixed"
    )

    # Load 7-day sample curriculum from sample_data/example_learning_plan.json
    sample_file = os.path.join(os.path.dirname(__file__), "sample_data", "example_learning_plan.json")
    with open(sample_file, "r", encoding="utf-8") as f:
        plan_data = json.load(f)

    print("Seeding study plan and topics...")
    plan_id = database.save_study_plan(
        learner_id=learner_id,
        subject=plan_data["subject"],
        goal=plan_data["goal"],
        total_days=plan_data["target_days"],
        summary=plan_data["summary"],
        topics_data=plan_data["topics"]
    )

    # Fetch topics
    topics = database.get_plan_topics(plan_id)

    # Mark Day 1 and Day 2 as completed
    if len(topics) >= 2:
        database.toggle_topic_completion(topics[0]["id"], True)
        database.toggle_topic_completion(topics[1]["id"], True)

    # Seed 2 realistic quiz attempts
    # Attempt 1 on Day 1 (Variables): Scored 80% (4/5) -> Strong
    q1 = [
        {"question": "Which is a valid variable name?", "options": {"A": "2var", "B": "my-var", "C": "_student_id", "D": "class"}, "correct_option": "C", "user_selected_option": "C", "is_correct": True, "explanation": "Identifiers can start with underscores.", "difficulty": "Beginner"},
        {"question": "Output of type(4 / 2)?", "options": {"A": "int", "B": "float", "C": "double", "D": "num"}, "correct_option": "B", "user_selected_option": "B", "is_correct": True, "explanation": "Division in Python 3 produces floats.", "difficulty": "Beginner"},
        {"question": "Converting '25' to integer?", "options": {"A": "to_int()", "B": "int('25')", "C": "parseInt()", "D": "cast()"}, "correct_option": "B", "user_selected_option": "B", "is_correct": True, "explanation": "int() handles type conversion.", "difficulty": "Beginner"},
        {"question": "Evaluation of bool([])?", "options": {"A": "True", "B": "False", "C": "None", "D": "Error"}, "correct_option": "B", "user_selected_option": "A", "is_correct": False, "explanation": "Empty collections evaluate to False.", "difficulty": "Medium"},
        {"question": "Formatted f-string syntax?", "options": {"A": "%s", "B": ".format()", "C": "f'{name}'", "D": "${name}"}, "correct_option": "C", "user_selected_option": "C", "is_correct": True, "explanation": "f-strings use f'...' notation.", "difficulty": "Beginner"}
    ]
    database.save_quiz_attempt(
        learner_id=learner_id,
        plan_id=plan_id,
        topic_id=topics[0]["id"],
        topic_name=topics[0]["topic_name"],
        total_questions=5,
        correct_answers=4,
        score_percentage=80.0,
        status="Good Progress",
        recommendation="Solid foundation in variables and types. Ready to proceed to operators and logic.",
        questions_evaluated=q1
    )

    # Attempt 2 on Day 3 (Loops): Scored 40% (2/5) -> Weak / Needs Revision (as in illustrative example)
    q2 = [
        {"question": "How many times does range(1, 6) loop?", "options": {"A": "4", "B": "5", "C": "6", "D": "inf"}, "correct_option": "B", "user_selected_option": "B", "is_correct": True, "explanation": "range(1, 6) loops 5 times.", "difficulty": "Beginner"},
        {"question": "Keyword to immediately exit a loop?", "options": {"A": "continue", "B": "break", "C": "pass", "D": "exit"}, "correct_option": "B", "user_selected_option": "B", "is_correct": True, "explanation": "break exits immediately.", "difficulty": "Beginner"},
        {"question": "What does continue do?", "options": {"A": "Quits loop", "B": "Skips to next iteration", "C": "Pauses", "D": "Restarts"}, "correct_option": "B", "user_selected_option": "A", "is_correct": False, "explanation": "continue skips the remainder of the current iteration.", "difficulty": "Medium"},
        {"question": "What causes an infinite while loop?", "options": {"A": "Break statement", "B": "Unmodified condition", "C": "Printing numbers", "D": "Fast execution"}, "correct_option": "B", "user_selected_option": "C", "is_correct": False, "explanation": "A condition that never becomes false causes an infinite loop.", "difficulty": "Beginner"},
        {"question": "What does list(range(0, 10, 3)) produce?", "options": {"A": "[0, 3, 6, 9]", "B": "[3, 6, 9]", "C": "[0, 3, 6]", "D": "[3, 6, 9, 10]"}, "correct_option": "A", "user_selected_option": "D", "is_correct": False, "explanation": "Step of 3 from 0 up to 10 gives 0, 3, 6, 9.", "difficulty": "Hard"}
    ]
    database.save_quiz_attempt(
        learner_id=learner_id,
        plan_id=plan_id,
        topic_id=topics[2]["id"],
        topic_name=topics[2]["topic_name"],
        total_questions=5,
        correct_answers=2,
        score_percentage=40.0,
        status="Needs Revision",
        recommendation="Loops scored 40%. Foundational review and practice questions recommended before advancing.",
        questions_evaluated=q2
    )

    # Seed 1 initial coach interaction
    database.save_chat_message(
        learner_id=learner_id,
        role="user",
        message="Hi! Can you give me a simple analogy to understand the difference between 'for' loops and 'while' loops?"
    )
    database.save_chat_message(
        learner_id=learner_id,
        role="assistant",
        message="Think of a **for loop** like reading a grocery list with 5 items: you already know how many items there are, and you check them off one by one.\n\nA **while loop** is like boiling water until the kettle whistles: you don't know the exact count of seconds in advance, you just keep waiting *while* the condition isn't met yet!\n\nUse **for** when you know the sequence length, and **while** when you're waiting for an event or condition."
    )

    print("Seed complete! Active learner Alex Johnson initialized with 7-day plan, 2 quizzes, and chat history.")

if __name__ == "__main__":
    seed()


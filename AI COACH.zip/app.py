"""
AI Personalized Learning Coach - Main Landing Page (Module 1).
A student-friendly educational portal with modern lavender & purple aesthetics.
"""

import streamlit as st
import os
from config import APP_NAME, APP_TAGLINE, APP_ICON, apply_custom_theme, render_sidebar_status, THEME_COLORS
import database

# Configure Streamlit page
st.set_page_config(
    page_title=f"{APP_NAME} - Home",
    page_icon=APP_ICON,
    layout="wide",
    initial_sidebar_state="expanded"
)

# Apply custom styles and sidebar status
apply_custom_theme()
render_sidebar_status()

# Fetch active learner state
active_learner = database.get_active_learner()

# --- HERO BANNER ---
st.markdown(
    f"""
    <div class="hero-banner">
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 8px;">
            <span style="font-size: 2.4rem;">{APP_ICON}</span>
            <span class="badge" style="background: rgba(255, 255, 255, 0.2); color: #FFFFFF; border: 1px solid rgba(255, 255, 255, 0.3);">
                AI Engineering Internship Project
            </span>
        </div>
        <h1 style="font-size: 2.6rem; line-height: 1.15; margin: 0 0 12px 0;">{APP_NAME}</h1>
        <p style="font-size: 1.15rem; line-height: 1.6; margin: 0 0 24px 0; color: #EDE9FE;">
            Empowering students with <strong>adaptive study plans</strong>, <strong>targeted practice quizzes</strong>, 
            <strong>Python-scored evaluations</strong>, and a <strong>context-aware AI tutor</strong> powered by Google Gemini.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# --- QUICK RESUME BANNER IF ACTIVE LEARNER EXISTS ---
if active_learner:
    summary = database.get_learner_progress_summary(active_learner["id"])
    active_plan = database.get_active_study_plan(active_learner["id"])
    
    st.markdown(
        f"""
        <div class="coach-card" style="border-left: 6px solid {THEME_COLORS['primary']}; background: #FAF5FF;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                <div>
                    <span class="badge badge-purple">Active Student</span>
                    <h3 style="margin: 6px 0 2px 0; color: #1E1B4B;">Welcome back, {active_learner['name']}! 👋</h3>
                    <p style="margin: 0; color: #64748B; font-size: 0.92rem;">
                        Subject: <strong>{active_learner['subject']}</strong> &bull; Level: <strong>{active_learner['knowledge_level']}</strong> &bull; 
                        Plan Progress: <strong>{summary['progress_percentage']}%</strong> ({summary['completed_topics']}/{summary['total_topics']} topics completed)
                    </p>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True
    )
    
    # Quick Navigation Buttons
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        if st.button("📖 Continue Study Plan", use_container_width=True, type="primary"):
            st.switch_page("pages/2_Study_Plan.py")
    with c2:
        if st.button("🎯 Practice Quiz", use_container_width=True):
            st.switch_page("pages/3_Practice_Quiz.py")
    with c3:
        if st.button("🤖 Ask AI Assistant", use_container_width=True):
            st.switch_page("pages/4_AI_Assistant.py")
    with c4:
        if st.button("📊 View Progress Dashboard", use_container_width=True):
            st.switch_page("pages/5_Progress_Dashboard.py")
    
    st.markdown("<div style='margin-bottom: 24px;'></div>", unsafe_allow_html=True)

else:
    # Call to action for new user
    col_cta1, col_cta2 = st.columns([2, 1])
    with col_cta1:
        st.markdown(
            """
            <div class="coach-card" style="background: linear-gradient(135deg, #FFFFFF 0%, #F5F3FF 100%);">
                <h3 style="color: #6D28D9; margin-top: 0;">🚀 Ready to accelerate your learning?</h3>
                <p style="color: #475569; font-size: 0.98rem; line-height: 1.6;">
                    Set up your learning goals, target duration, and preferred study style to generate your first custom AI curriculum.
                </p>
            </div>
            """,
            unsafe_allow_html=True
        )
    with col_cta2:
        st.markdown("<div style='height: 18px;'></div>", unsafe_allow_html=True)
        if st.button("✨ Start Learning Now", use_container_width=True, type="primary"):
            st.switch_page("pages/1_Learning_Profile.py")

# --- FEATURES SECTION ---
st.markdown("### 🌟 Key Intelligent Features")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(
        f"""
        <div class="coach-card" style="height: 240px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <div style="font-size: 2rem; margin-bottom: 8px;">🗓️</div>
                <h4 style="margin: 0 0 8px 0; color: #1E1B4B;">Personalized Plan</h4>
                <p style="color: #64748B; font-size: 0.88rem; line-height: 1.5; margin: 0;">
                    Tailored day-by-day roadmap considering your goals, daily minutes, and preferred learning style.
                </p>
            </div>
            <span class="badge badge-purple">Gemini Powered</span>
        </div>
        """,
        unsafe_allow_html=True
    )

with col2:
    st.markdown(
        f"""
        <div class="coach-card" style="height: 240px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <div style="font-size: 2rem; margin-bottom: 8px;">🎯</div>
                <h4 style="margin: 0 0 8px 0; color: #1E1B4B;">Targeted Quizzes</h4>
                <p style="color: #64748B; font-size: 0.88rem; line-height: 1.5; margin: 0;">
                    Topic-based 5-question multiple choice quizzes evaluated instantly in Python with detailed explanations.
                </p>
            </div>
            <span class="badge badge-success">Python Scored</span>
        </div>
        """,
        unsafe_allow_html=True
    )

with col3:
    st.markdown(
        f"""
        <div class="coach-card" style="height: 240px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <div style="font-size: 2rem; margin-bottom: 8px;">📈</div>
                <h4 style="margin: 0 0 8px 0; color: #1E1B4B;">Adaptive Analysis</h4>
                <p style="color: #64748B; font-size: 0.88rem; line-height: 1.5; margin: 0;">
                    Automatic identification of weak topics (&lt; 70%) with concrete revision tasks and next steps.
                </p>
            </div>
            <span class="badge badge-warning">SQLite Backed</span>
        </div>
        """,
        unsafe_allow_html=True
    )

with col4:
    st.markdown(
        f"""
        <div class="coach-card" style="height: 240px; display: flex; flex-direction: column; justify-content: space-between;">
            <div>
                <div style="font-size: 2rem; margin-bottom: 8px;">🤖</div>
                <h4 style="margin: 0 0 8px 0; color: #1E1B4B;">24/7 AI Coach</h4>
                <p style="color: #64748B; font-size: 0.88rem; line-height: 1.5; margin: 0;">
                    Context-aware assistant that knows your current topics, explains tricky code, and suggests challenges.
                </p>
            </div>
            <span class="badge badge-purple">Session Context</span>
        </div>
        """,
        unsafe_allow_html=True
    )

# --- HOW IT WORKS SECTION ---
st.markdown("### 🔄 How It Works")
step_c1, step_c2, step_c3, step_c4 = st.columns(4)

steps = [
    ("1. Define Profile", "Enter subject, goal, level, target days, and daily study time in minutes.", "👤"),
    ("2. Generate Plan", "Gemini structures a day-wise curriculum with objectives and practical tasks.", "📋"),
    ("3. Study & Quiz", "Study each day's topic, take 5-question quizzes, and receive Python-scored feedback.", "📝"),
    ("4. Adapt & Master", "Identify weak areas, review explanations, ask the AI tutor, and track progress.", "🏆")
]

for col, (title, desc, icon) in zip([step_c1, step_c2, step_c3, step_c4], steps):
    with col:
        st.markdown(
            f"""
            <div class="coach-card" style="text-align: center; height: 210px;">
                <div style="width: 48px; height: 48px; border-radius: 50%; background: #EDE9FE; color: #6D28D9; font-size: 22px; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px auto; font-weight: bold;">
                    {icon}
                </div>
                <h4 style="margin: 0 0 6px 0; color: #1E1B4B; font-size: 1.02rem;">{title}</h4>
                <p style="color: #64748B; font-size: 0.84rem; line-height: 1.5; margin: 0;">{desc}</p>
            </div>
            """,
            unsafe_allow_html=True
        )

# --- BENEFITS OF PERSONALIZED LEARNING ---
st.markdown("### 💡 Why Personalized Learning Works")
b_col1, b_col2 = st.columns(2)

with b_col1:
    st.markdown(
        """
        <div class="coach-card">
            <h4 style="color: #6D28D9; margin-top: 0;">🎓 The Problem With One-Size-Fits-All Curriculums</h4>
            <ul style="color: #475569; font-size: 0.92rem; line-height: 1.8; margin-bottom: 0;">
                <li>Students struggle when generic courses move too fast or too slow for their background.</li>
                <li>Learners lack visibility into which specific sub-topics are actually weak vs mastered.</li>
                <li>Traditional static quizzes only show a percentage without adaptive remedial actions.</li>
                <li>Busy professionals and students have varying daily schedules (15 mins vs 90 mins).</li>
            </ul>
        </div>
        """,
        unsafe_allow_html=True
    )

with b_col2:
    st.markdown(
        """
        <div class="coach-card">
            <h4 style="color: #6D28D9; margin-top: 0;">✨ The AI Personalized Learning Coach Solution</h4>
            <ul style="color: #475569; font-size: 0.92rem; line-height: 1.8; margin-bottom: 0;">
                <li><strong>Dynamic Pacing:</strong> Calculates daily milestones matched exactly to your available minutes.</li>
                <li><strong>Targeted Feedback:</strong> Every question provides comprehensive pedagogical explanations.</li>
                <li><strong>Weak-Topic Flagging:</strong> Any topic scoring below 70% is queued for targeted revision drills.</li>
                <li><strong>Persistent SQLite Storage:</strong> All plans, attempts, and chat history persist across restarts.</li>
            </ul>
        </div>
        """,
        unsafe_allow_html=True
    )

st.markdown("---")
col_footer_l, col_footer_r = st.columns([3, 1])
with col_footer_l:
    st.caption("AI Engineering Internship Project Brief • Xpert Champs | Built with Python, Streamlit, Google Gemini & SQLite")
with col_footer_r:
    if st.button("🚀 Get Started Now →", use_container_width=True, type="primary"):
        st.switch_page("pages/1_Learning_Profile.py")

